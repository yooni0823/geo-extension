chrome.runtime.onInstalled.addListener(()=>{chrome.sidePanel.setPanelBehavior({openPanelOnActionClick:!0}).catch(()=>{console.warn("Unable to enable side panel action behavior.")})});
